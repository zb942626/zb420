package computer;

public interface Disk {
    String getDisk();
}
