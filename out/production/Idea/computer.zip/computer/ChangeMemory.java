package computer;

public class ChangeMemory  implements Memory{
    @Override
    public String getMemory() {
        return "4G";
    }
}
