package computer;

public class ChangeDisk implements Disk {
    @Override
    public String getDisk() {
        return "3000GB";
    }
}
