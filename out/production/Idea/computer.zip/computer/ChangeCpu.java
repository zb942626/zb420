package computer;

public class ChangeCpu implements Cpu {
    @Override
    public String getCpu() {
        return "Intel";
    }
}
