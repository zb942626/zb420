package computer;

public interface Cpu {
    String getCpu();
}
