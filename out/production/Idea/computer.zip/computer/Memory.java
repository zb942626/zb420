package computer;

public interface Memory {
    String getMemory();
}

