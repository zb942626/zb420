package people;

public class Person {


    public String name1 ="小明";
    public String getName1() {
        return name1;
    }

    public void setName1(String name1) {
        this.name1 = name1;
    }

}

