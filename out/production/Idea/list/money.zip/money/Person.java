package list.money;

public class Person {
    static String[] names ={"李彤","海菊","长菏","腾琳","梁茹","新儒"};
     int money;
     String name;

}
