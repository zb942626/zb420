package graphics;

public class Rectangle extends Graphics {
    public static void main(String[] args) {
        Rectangle rectangle =new Rectangle();
        rectangle.chang=10;
        rectangle.kuan=15;
         rectangle.area(rectangle);

    }


}
