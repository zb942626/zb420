package graphics;

public class Circular extends  Graphics {
    public static void main(String[] args) {
        Circular circular=new Circular();
        circular.banjing=4.5;
        circular.area(circular);
    }
}
