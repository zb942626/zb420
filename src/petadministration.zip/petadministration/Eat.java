package petadministration;

public class Eat {
    public void feed(Pet pet){
        pet.eat();
    }
}
