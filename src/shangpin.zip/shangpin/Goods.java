package shangpin;

public abstract class Goods {
    String name;
    double money;
    public abstract void print();
}
